package basic9;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Splasher extends Unit {

    Splasher(RobotController rc) throws GameActionException {
        super(rc);
    }

    void startTurn(){

    }

    void runTurn(){

    }

    void endTurn(){

    }

}